import React from "react";

const Detail = () => {
    return (
        <div>
           Detail
        </div>

    );
}

export default Detail;